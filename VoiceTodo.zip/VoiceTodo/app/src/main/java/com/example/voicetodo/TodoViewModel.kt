package com.example.voicetodo

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class UiState(
    val todos: List<TodoItem> = emptyList(),
    val listening: Boolean = false,
    val partial: String = "",
    val transcript: String = "",
    val error: String? = null
)

class TodoViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = TodoRepository(app)
    private val _state = MutableStateFlow(UiState(todos = repo.load()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val speech = SpeechManager(
        context = app,
        onPartial = { p -> _state.update { it.copy(partial = p) } },
        onFinal = ::handleFinal,
        onError = { msg -> _state.update { it.copy(error = msg, partial = "") } },
        onListeningChanged = { on -> _state.update { it.copy(listening = on, partial = if (on) it.partial else "") } }
    )

    fun toggleListening() {
        if (_state.value.listening) speech.stop() else {
            _state.update { it.copy(error = null) }
            speech.start()
        }
    }

    fun onPermissionDenied() {
        _state.update { it.copy(error = "Microphone permission denied. Enable it in system settings to use voice input.") }
    }

    private fun handleFinal(text: String) {
        val extracted = TaskExtractor.extract(text)
        _state.update { s ->
            val existing = s.todos.map { it.title.lowercase() }.toSet()
            val now = System.currentTimeMillis()
            val added = extracted
                .filter { it.title.lowercase() !in existing }
                .mapIndexed { i, t -> TodoItem(id = now + i, title = t.title, due = t.due) }
            val todos = s.todos + added
            if (added.isNotEmpty()) repo.save(todos)
            s.copy(
                todos = todos,
                partial = "",
                transcript = if (s.transcript.isEmpty()) text else s.transcript + "\n" + text
            )
        }
    }

    fun addManual(title: String) {
        val t = title.trim()
        if (t.isEmpty()) return
        update { it + TodoItem(id = System.currentTimeMillis(), title = t) }
    }

    fun toggle(id: Long) = update { list -> list.map { if (it.id == id) it.copy(done = !it.done) else it } }
    fun delete(id: Long) = update { list -> list.filterNot { it.id == id } }
    fun clearDone() = update { list -> list.filterNot { it.done } }
    fun clearTranscript() = _state.update { it.copy(transcript = "", partial = "") }
    fun dismissError() = _state.update { it.copy(error = null) }

    private fun update(block: (List<TodoItem>) -> List<TodoItem>) {
        _state.update { s ->
            val todos = block(s.todos)
            repo.save(todos)
            s.copy(todos = todos)
        }
    }

    override fun onCleared() {
        speech.destroy()
    }
}
