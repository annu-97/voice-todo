package com.example.voicetodo

data class ExtractedTask(val title: String, val due: String?)

/**
 * Rule-based, fully offline task detector.
 * Finds phrases like "I need to ...", "remind me to ...", or sentences that start with an action verb,
 * and pulls out simple time hints ("tomorrow", "by Friday", "at 5 pm").
 *
 * To use an LLM instead, replace extract() with a call to your own backend.
 */
object TaskExtractor {

    private val verbs = listOf(
        "call", "email", "text", "message", "buy", "pick", "send", "book", "schedule", "pay",
        "finish", "write", "clean", "cancel", "order", "renew", "submit", "review", "fix",
        "update", "check", "plan", "prepare", "bring", "return", "visit", "file", "organize",
        "print", "sign", "reply", "follow", "water", "walk", "cook", "wash", "take", "get",
        "set", "make", "create", "read", "study", "draft", "ask", "tell", "grab", "drop"
    )
    private val verbSet = verbs.toSet()

    private const val DAYS = "monday|tuesday|wednesday|thursday|friday|saturday|sunday"

    private val splitter = Regex(
        "(?<=[.!?])\\s+|\\n+|;\\s*" +
            "|,?\\s+(?:and then|and also|then|also|after that)\\s+" +
            "|\\s+and\\s+(?=(?:${verbs.joinToString("|")})\\b)",
        RegexOption.IGNORE_CASE
    )

    private val filler = Regex(
        "^(?:(?:um+|uh+|so|okay|ok|oh|yeah|well|and|also|then|please|hey)[,\\s]+)+",
        RegexOption.IGNORE_CASE
    )

    private val leadIn = Regex(
        "\\b(?:remind me to|don't forget to|do not forget to|remember to|make sure (?:to|i|we)|" +
            "i need to|i have to|i've got to|i gotta|i got to|i should|i must|i want to|i'd like to|" +
            "we need to|we have to|we should|need to|have to|gotta)\\s+",
        RegexOption.IGNORE_CASE
    )

    private val dueRegex = Regex(
        "\\b(?:(?:by|on|before|until|this|next)\\s+(?:$DAYS)" +
            "|(?:by|before)\\s+(?:tomorrow|tonight|today|end of (?:the )?(?:day|week|month))" +
            "|next\\s+(?:week|month)" +
            "|this\\s+(?:morning|afternoon|evening|weekend)" +
            "|tonight|tomorrow|today" +
            "|at\\s+\\d{1,2}(?::\\d{2})?\\s?(?:am|pm)?" +
            "|in\\s+\\d+\\s+(?:minutes?|hours?|days?|weeks?))\\b",
        RegexOption.IGNORE_CASE
    )

    fun extract(transcript: String): List<ExtractedTask> {
        val text = transcript.replace('\u2019', '\'')
        val seen = mutableSetOf<String>()
        val out = mutableListOf<ExtractedTask>()

        for (raw in text.split(splitter)) {
            val clause = raw.trim().replace(filler, "").trim()
            if (clause.isBlank()) continue

            val lead = leadIn.find(clause)
            val body = when {
                lead != null -> clause.substring(lead.range.last + 1)
                clause.endsWith("?") -> continue
                clause.substringBefore(' ').lowercase().trim(',', '.') in verbSet -> clause
                else -> continue
            }

            val due = dueRegex.find(clause)?.value?.trim()
            val title = body.replace(dueRegex, "")
                .replace(Regex("\\s+"), " ")
                .trim(' ', ',', '.', '!', '?')
            if (title.length < 3) continue

            val pretty = title.replaceFirstChar { it.uppercase() }
            if (seen.add(pretty.lowercase())) out += ExtractedTask(pretty, due)
        }
        return out
    }
}
