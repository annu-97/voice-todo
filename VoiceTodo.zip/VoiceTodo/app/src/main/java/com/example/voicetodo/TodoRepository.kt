package com.example.voicetodo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TodoItem(
    val id: Long,
    val title: String,
    val due: String? = null,
    val done: Boolean = false
)

/** Tiny persistence layer: the whole list is stored as JSON in SharedPreferences. */
class TodoRepository(context: Context) {
    private val prefs = context.getSharedPreferences("todos", Context.MODE_PRIVATE)

    fun load(): List<TodoItem> {
        val raw = prefs.getString("items", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                TodoItem(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    due = if (o.isNull("due")) null else o.getString("due"),
                    done = o.optBoolean("done")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(items: List<TodoItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("due", it.due ?: JSONObject.NULL)
                    .put("done", it.done)
            )
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
