package com.example.voicetodo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VoiceTodoScreen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceTodoScreen(vm: TodoViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) vm.toggleListening() else vm.onPermissionDenied() }

    fun onMicClick() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (state.listening || hasPermission) vm.toggleListening()
        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Voice Todo") },
                actions = { TextButton(onClick = { vm.clearDone() }) { Text("Clear done") } }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { onMicClick() }) {
                Text(if (state.listening) "Stop listening" else "Start listening", modifier = Modifier.padding(horizontal = 8.dp))
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .fillMaxSize()
        ) {
            state.error?.let { msg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(msg, Modifier.weight(1f), color = MaterialTheme.colorScheme.onErrorContainer)
                        TextButton(onClick = { vm.dismissError() }) { Text("OK") }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            if (state.listening || state.transcript.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (state.listening) "Listening…" else "Transcript",
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.weight(1f)
                            )
                            if (state.transcript.isNotEmpty() && !state.listening) {
                                TextButton(onClick = { vm.clearTranscript() }) { Text("Clear") }
                            }
                        }
                        val shown = listOf(state.transcript, state.partial).filter { it.isNotEmpty() }.joinToString("\n")
                        Text(shown.ifEmpty { "Say something like: \"I need to call Sam tomorrow and buy milk.\"" },
                            style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            var manual by remember { mutableStateOf("") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = manual,
                    onValueChange = { manual = it },
                    placeholder = { Text("Add a task manually") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { vm.addManual(manual); manual = "" }) { Text("Add") }
            }
            Spacer(Modifier.height(8.dp))

            if (state.todos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No tasks yet. Tap \"Start listening\" and talk.", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 88.dp)) {
                    items(state.todos, key = { it.id }) { todo ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = todo.done, onCheckedChange = { vm.toggle(todo.id) })
                            Column(Modifier.weight(1f)) {
                                Text(
                                    todo.title,
                                    textDecoration = if (todo.done) TextDecoration.LineThrough else null,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                todo.due?.let {
                                    Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            IconButton(onClick = { vm.delete(todo.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}
