# Voice Todo

Speak, and tasks appear in your to-do list.

**Open:** Android Studio (Koala or newer) → Open → select the `VoiceTodo` folder → let Gradle sync → Run.
Android Studio will fetch the Gradle wrapper jar if it's missing.

**How it works**
1. `SpeechManager` – continuous speech-to-text via Android's built-in `SpeechRecognizer`.
2. `TaskExtractor` – offline rules that find tasks ("I need to…", "remind me to…", sentences starting with an action verb) and time hints ("tomorrow", "by Friday", "at 5 pm").
3. `TodoRepository` – saves the list as JSON in SharedPreferences.
4. `MainActivity` – Jetpack Compose UI: transcript card, manual add, checklist.

**Notes**
- On many devices the recognizer is cloud-backed (Google app), so it may need internet.
- Task detection is heuristic. To use an LLM, swap `TaskExtractor.extract()` for a call to your own backend (don't ship an API key inside the app).
